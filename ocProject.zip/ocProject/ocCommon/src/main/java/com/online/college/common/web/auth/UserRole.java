package com.online.college.common.web.auth;

import java.io.Serializable;

/**
 * 权限角色
 * @author Brain
 */
public class UserRole implements Serializable{

	private static final long serialVersionUID = 406004317093554289L;

	
	
}
