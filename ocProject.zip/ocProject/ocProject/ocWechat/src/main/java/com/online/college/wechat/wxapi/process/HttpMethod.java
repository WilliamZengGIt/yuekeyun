package com.online.college.wechat.wxapi.process;

/**
 * 
 */
public class HttpMethod {

	public static final String POST = "POST";
	public static final String GET = "GET";
	
}
